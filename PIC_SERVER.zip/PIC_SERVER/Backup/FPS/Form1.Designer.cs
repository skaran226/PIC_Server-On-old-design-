﻿namespace FPS
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.btPending = new System.Windows.Forms.Button();
            this.btCompleted = new System.Windows.Forms.Button();
            this.btEOD = new System.Windows.Forms.Button();
            this.btCash = new System.Windows.Forms.Button();
            this.btPrint = new System.Windows.Forms.Button();
            this.btGenerate = new System.Windows.Forms.Button();
            this.btConfigure = new System.Windows.Forms.Button();
            this.btStatus = new System.Windows.Forms.Button();
            this.btUpdate = new System.Windows.Forms.Button();
            this.btRestart = new System.Windows.Forms.Button();
            this.lbPicNum = new System.Windows.Forms.Label();
            this.tbPicNum = new System.Windows.Forms.TextBox();
            this.tbPumpNum = new System.Windows.Forms.TextBox();
            this.lbPumpNum = new System.Windows.Forms.Label();
            this.tbMaxBills = new System.Windows.Forms.TextBox();
            this.lbMaxBills = new System.Windows.Forms.Label();
            this.tbMaxCash = new System.Windows.Forms.TextBox();
            this.lbMaxCash = new System.Windows.Forms.Label();
            this.tbGrade4 = new System.Windows.Forms.TextBox();
            this.lbGrade4 = new System.Windows.Forms.Label();
            this.tbGrade3 = new System.Windows.Forms.TextBox();
            this.lbGrade3 = new System.Windows.Forms.Label();
            this.tbGrade2 = new System.Windows.Forms.TextBox();
            this.lbGrade2 = new System.Windows.Forms.Label();
            this.tbGrade1 = new System.Windows.Forms.TextBox();
            this.lbGrade1 = new System.Windows.Forms.Label();
            this.tbFooter = new System.Windows.Forms.TextBox();
            this.lbFooter = new System.Windows.Forms.Label();
            this.tbHeader = new System.Windows.Forms.TextBox();
            this.lbHeader = new System.Windows.Forms.Label();
            this.btDateTime = new System.Windows.Forms.Button();
            this.btSave = new System.Windows.Forms.Button();
            this.btCancel = new System.Windows.Forms.Button();
            this.lbWarning = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btShutDown = new System.Windows.Forms.Button();
            this.tbGrade6 = new System.Windows.Forms.TextBox();
            this.lbGrade6 = new System.Windows.Forms.Label();
            this.tbGrade5 = new System.Windows.Forms.TextBox();
            this.lbGrade5 = new System.Windows.Forms.Label();
            this.btPageDown = new System.Windows.Forms.Button();
            this.btPageUp = new System.Windows.Forms.Button();
            this.btLoggingSFC = new System.Windows.Forms.Button();
            this.btLoggingPIC = new System.Windows.Forms.Button();
            this.btDownloadReports = new System.Windows.Forms.Button();
            this.btDownloadData = new System.Windows.Forms.Button();
            this.btDownloadLogs = new System.Windows.Forms.Button();
            this.btClear = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Yellow;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(8, 6);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(360, 50);
            this.button1.TabIndex = 1;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Yellow;
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(8, 52);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(360, 50);
            this.button2.TabIndex = 2;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Yellow;
            this.button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(8, 97);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(360, 50);
            this.button3.TabIndex = 3;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Yellow;
            this.button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(8, 143);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(360, 50);
            this.button4.TabIndex = 4;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Yellow;
            this.button5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(8, 190);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(360, 50);
            this.button5.TabIndex = 5;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button6.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Yellow;
            this.button6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(8, 237);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(360, 50);
            this.button6.TabIndex = 6;
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button7.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Yellow;
            this.button7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Location = new System.Drawing.Point(8, 284);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(360, 50);
            this.button7.TabIndex = 7;
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button8.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Yellow;
            this.button8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.Location = new System.Drawing.Point(8, 330);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(360, 50);
            this.button8.TabIndex = 8;
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button9.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Yellow;
            this.button9.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.Location = new System.Drawing.Point(8, 376);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(360, 50);
            this.button9.TabIndex = 9;
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button10.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Yellow;
            this.button10.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.Location = new System.Drawing.Point(8, 423);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(360, 50);
            this.button10.TabIndex = 10;
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // btPending
            // 
            this.btPending.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btPending.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Yellow;
            this.btPending.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btPending.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btPending.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btPending.Location = new System.Drawing.Point(415, 80);
            this.btPending.Name = "btPending";
            this.btPending.Size = new System.Drawing.Size(160, 50);
            this.btPending.TabIndex = 11;
            this.btPending.Text = "PENDING\r\nTRANSACTIONS";
            this.btPending.UseVisualStyleBackColor = true;
            this.btPending.Click += new System.EventHandler(this.btPending_Click);
            // 
            // btCompleted
            // 
            this.btCompleted.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btCompleted.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Yellow;
            this.btCompleted.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btCompleted.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btCompleted.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCompleted.Location = new System.Drawing.Point(618, 80);
            this.btCompleted.Name = "btCompleted";
            this.btCompleted.Size = new System.Drawing.Size(160, 50);
            this.btCompleted.TabIndex = 12;
            this.btCompleted.Text = "STORED\r\nTRANSACTIONS\r\n";
            this.btCompleted.UseVisualStyleBackColor = true;
            this.btCompleted.Click += new System.EventHandler(this.btCompleted_Click);
            // 
            // btEOD
            // 
            this.btEOD.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btEOD.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Yellow;
            this.btEOD.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btEOD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btEOD.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btEOD.Location = new System.Drawing.Point(415, 140);
            this.btEOD.Name = "btEOD";
            this.btEOD.Size = new System.Drawing.Size(160, 50);
            this.btEOD.TabIndex = 13;
            this.btEOD.Text = "END OF DAY\r\nREPORTS";
            this.btEOD.UseVisualStyleBackColor = true;
            this.btEOD.Click += new System.EventHandler(this.btEOD_Click);
            // 
            // btCash
            // 
            this.btCash.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btCash.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Yellow;
            this.btCash.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btCash.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btCash.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCash.Location = new System.Drawing.Point(618, 141);
            this.btCash.Name = "btCash";
            this.btCash.Size = new System.Drawing.Size(160, 50);
            this.btCash.TabIndex = 14;
            this.btCash.Text = "PIC CASH\r\nREPORTS";
            this.btCash.UseVisualStyleBackColor = true;
            this.btCash.Click += new System.EventHandler(this.btCash_Click);
            // 
            // btPrint
            // 
            this.btPrint.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btPrint.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Yellow;
            this.btPrint.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btPrint.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btPrint.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btPrint.Location = new System.Drawing.Point(414, 278);
            this.btPrint.Name = "btPrint";
            this.btPrint.Size = new System.Drawing.Size(363, 51);
            this.btPrint.TabIndex = 15;
            this.btPrint.Text = "PRINT";
            this.btPrint.UseVisualStyleBackColor = true;
            this.btPrint.Click += new System.EventHandler(this.btPrint_Click);
            // 
            // btGenerate
            // 
            this.btGenerate.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btGenerate.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Yellow;
            this.btGenerate.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btGenerate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btGenerate.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btGenerate.Location = new System.Drawing.Point(415, 339);
            this.btGenerate.Name = "btGenerate";
            this.btGenerate.Size = new System.Drawing.Size(363, 50);
            this.btGenerate.TabIndex = 16;
            this.btGenerate.Text = "GENERATE REPORT";
            this.btGenerate.UseVisualStyleBackColor = true;
            this.btGenerate.Click += new System.EventHandler(this.btGenerate_Click);
            // 
            // btConfigure
            // 
            this.btConfigure.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btConfigure.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Yellow;
            this.btConfigure.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btConfigure.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btConfigure.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btConfigure.Location = new System.Drawing.Point(618, 200);
            this.btConfigure.Name = "btConfigure";
            this.btConfigure.Size = new System.Drawing.Size(160, 50);
            this.btConfigure.TabIndex = 17;
            this.btConfigure.Text = "CONFIGURE";
            this.btConfigure.UseVisualStyleBackColor = true;
            this.btConfigure.Click += new System.EventHandler(this.btConfigure_Click);
            // 
            // btStatus
            // 
            this.btStatus.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btStatus.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Yellow;
            this.btStatus.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btStatus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btStatus.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btStatus.Location = new System.Drawing.Point(415, 200);
            this.btStatus.Name = "btStatus";
            this.btStatus.Size = new System.Drawing.Size(160, 50);
            this.btStatus.TabIndex = 18;
            this.btStatus.Text = "STATUS";
            this.btStatus.UseVisualStyleBackColor = true;
            this.btStatus.Click += new System.EventHandler(this.btStatus_Click);
            // 
            // btUpdate
            // 
            this.btUpdate.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btUpdate.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Yellow;
            this.btUpdate.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btUpdate.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btUpdate.Location = new System.Drawing.Point(414, 339);
            this.btUpdate.Name = "btUpdate";
            this.btUpdate.Size = new System.Drawing.Size(364, 50);
            this.btUpdate.TabIndex = 19;
            this.btUpdate.Text = "APPLICATION UPDATE";
            this.btUpdate.UseVisualStyleBackColor = true;
            this.btUpdate.Click += new System.EventHandler(this.btUpdate_Click);
            // 
            // btRestart
            // 
            this.btRestart.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btRestart.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Yellow;
            this.btRestart.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btRestart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btRestart.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btRestart.Location = new System.Drawing.Point(415, 420);
            this.btRestart.Name = "btRestart";
            this.btRestart.Size = new System.Drawing.Size(160, 50);
            this.btRestart.TabIndex = 20;
            this.btRestart.Text = "RESTART";
            this.btRestart.UseVisualStyleBackColor = true;
            this.btRestart.Click += new System.EventHandler(this.btRestart_Click);
            // 
            // lbPicNum
            // 
            this.lbPicNum.AutoSize = true;
            this.lbPicNum.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPicNum.Location = new System.Drawing.Point(12, 16);
            this.lbPicNum.Name = "lbPicNum";
            this.lbPicNum.Size = new System.Drawing.Size(93, 19);
            this.lbPicNum.TabIndex = 22;
            this.lbPicNum.Text = "PIC Count:";
            // 
            // tbPicNum
            // 
            this.tbPicNum.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbPicNum.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbPicNum.Location = new System.Drawing.Point(111, 14);
            this.tbPicNum.MaxLength = 1;
            this.tbPicNum.Name = "tbPicNum";
            this.tbPicNum.Size = new System.Drawing.Size(34, 26);
            this.tbPicNum.TabIndex = 23;
            // 
            // tbPumpNum
            // 
            this.tbPumpNum.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbPumpNum.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbPumpNum.Location = new System.Drawing.Point(308, 14);
            this.tbPumpNum.MaxLength = 2;
            this.tbPumpNum.Name = "tbPumpNum";
            this.tbPumpNum.Size = new System.Drawing.Size(34, 26);
            this.tbPumpNum.TabIndex = 25;
            // 
            // lbPumpNum
            // 
            this.lbPumpNum.AutoSize = true;
            this.lbPumpNum.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPumpNum.Location = new System.Drawing.Point(191, 16);
            this.lbPumpNum.Name = "lbPumpNum";
            this.lbPumpNum.Size = new System.Drawing.Size(111, 19);
            this.lbPumpNum.TabIndex = 24;
            this.lbPumpNum.Text = "Pump Count:";
            // 
            // tbMaxBills
            // 
            this.tbMaxBills.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbMaxBills.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbMaxBills.Location = new System.Drawing.Point(280, 59);
            this.tbMaxBills.MaxLength = 3;
            this.tbMaxBills.Name = "tbMaxBills";
            this.tbMaxBills.Size = new System.Drawing.Size(34, 26);
            this.tbMaxBills.TabIndex = 29;
            // 
            // lbMaxBills
            // 
            this.lbMaxBills.AutoSize = true;
            this.lbMaxBills.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMaxBills.Location = new System.Drawing.Point(191, 62);
            this.lbMaxBills.Name = "lbMaxBills";
            this.lbMaxBills.Size = new System.Drawing.Size(83, 19);
            this.lbMaxBills.TabIndex = 28;
            this.lbMaxBills.Text = "Max Bills:";
            // 
            // tbMaxCash
            // 
            this.tbMaxCash.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbMaxCash.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbMaxCash.Location = new System.Drawing.Point(108, 59);
            this.tbMaxCash.MaxLength = 3;
            this.tbMaxCash.Name = "tbMaxCash";
            this.tbMaxCash.Size = new System.Drawing.Size(34, 26);
            this.tbMaxCash.TabIndex = 27;
            // 
            // lbMaxCash
            // 
            this.lbMaxCash.AutoSize = true;
            this.lbMaxCash.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMaxCash.Location = new System.Drawing.Point(12, 62);
            this.lbMaxCash.Name = "lbMaxCash";
            this.lbMaxCash.Size = new System.Drawing.Size(90, 19);
            this.lbMaxCash.TabIndex = 26;
            this.lbMaxCash.Text = "Max Cash:";
            // 
            // tbGrade4
            // 
            this.tbGrade4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbGrade4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbGrade4.Location = new System.Drawing.Point(270, 146);
            this.tbGrade4.MaxLength = 4;
            this.tbGrade4.Name = "tbGrade4";
            this.tbGrade4.Size = new System.Drawing.Size(50, 26);
            this.tbGrade4.TabIndex = 37;
            // 
            // lbGrade4
            // 
            this.lbGrade4.AutoSize = true;
            this.lbGrade4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbGrade4.Location = new System.Drawing.Point(195, 147);
            this.lbGrade4.Name = "lbGrade4";
            this.lbGrade4.Size = new System.Drawing.Size(74, 19);
            this.lbGrade4.TabIndex = 36;
            this.lbGrade4.Text = "Grade 4:";
            // 
            // tbGrade3
            // 
            this.tbGrade3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbGrade3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbGrade3.Location = new System.Drawing.Point(87, 146);
            this.tbGrade3.MaxLength = 4;
            this.tbGrade3.Name = "tbGrade3";
            this.tbGrade3.Size = new System.Drawing.Size(50, 26);
            this.tbGrade3.TabIndex = 35;
            // 
            // lbGrade3
            // 
            this.lbGrade3.AutoSize = true;
            this.lbGrade3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbGrade3.Location = new System.Drawing.Point(16, 147);
            this.lbGrade3.Name = "lbGrade3";
            this.lbGrade3.Size = new System.Drawing.Size(74, 19);
            this.lbGrade3.TabIndex = 34;
            this.lbGrade3.Text = "Grade 3:";
            // 
            // tbGrade2
            // 
            this.tbGrade2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbGrade2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbGrade2.Location = new System.Drawing.Point(270, 104);
            this.tbGrade2.MaxLength = 4;
            this.tbGrade2.Name = "tbGrade2";
            this.tbGrade2.Size = new System.Drawing.Size(50, 26);
            this.tbGrade2.TabIndex = 33;
            // 
            // lbGrade2
            // 
            this.lbGrade2.AutoSize = true;
            this.lbGrade2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbGrade2.Location = new System.Drawing.Point(195, 106);
            this.lbGrade2.Name = "lbGrade2";
            this.lbGrade2.Size = new System.Drawing.Size(74, 19);
            this.lbGrade2.TabIndex = 32;
            this.lbGrade2.Text = "Grade 2:";
            // 
            // tbGrade1
            // 
            this.tbGrade1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbGrade1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbGrade1.Location = new System.Drawing.Point(87, 101);
            this.tbGrade1.MaxLength = 4;
            this.tbGrade1.Name = "tbGrade1";
            this.tbGrade1.Size = new System.Drawing.Size(50, 26);
            this.tbGrade1.TabIndex = 31;
            // 
            // lbGrade1
            // 
            this.lbGrade1.AutoSize = true;
            this.lbGrade1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbGrade1.Location = new System.Drawing.Point(16, 106);
            this.lbGrade1.Name = "lbGrade1";
            this.lbGrade1.Size = new System.Drawing.Size(74, 19);
            this.lbGrade1.TabIndex = 30;
            this.lbGrade1.Text = "Grade 1:";
            // 
            // tbFooter
            // 
            this.tbFooter.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbFooter.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbFooter.Location = new System.Drawing.Point(87, 312);
            this.tbFooter.MaxLength = 1000;
            this.tbFooter.Multiline = true;
            this.tbFooter.Name = "tbFooter";
            this.tbFooter.Size = new System.Drawing.Size(253, 75);
            this.tbFooter.TabIndex = 41;
            // 
            // lbFooter
            // 
            this.lbFooter.AutoSize = true;
            this.lbFooter.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbFooter.Location = new System.Drawing.Point(16, 312);
            this.lbFooter.Name = "lbFooter";
            this.lbFooter.Size = new System.Drawing.Size(65, 19);
            this.lbFooter.TabIndex = 40;
            this.lbFooter.Text = "Footer:";
            // 
            // tbHeader
            // 
            this.tbHeader.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbHeader.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHeader.Location = new System.Drawing.Point(87, 223);
            this.tbHeader.MaxLength = 1000;
            this.tbHeader.Multiline = true;
            this.tbHeader.Name = "tbHeader";
            this.tbHeader.Size = new System.Drawing.Size(253, 81);
            this.tbHeader.TabIndex = 39;
            // 
            // lbHeader
            // 
            this.lbHeader.AutoSize = true;
            this.lbHeader.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbHeader.Location = new System.Drawing.Point(16, 223);
            this.lbHeader.Name = "lbHeader";
            this.lbHeader.Size = new System.Drawing.Size(70, 19);
            this.lbHeader.TabIndex = 38;
            this.lbHeader.Text = "Header:";
            // 
            // btDateTime
            // 
            this.btDateTime.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btDateTime.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Yellow;
            this.btDateTime.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btDateTime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btDateTime.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btDateTime.Location = new System.Drawing.Point(8, 420);
            this.btDateTime.Name = "btDateTime";
            this.btDateTime.Size = new System.Drawing.Size(105, 50);
            this.btDateTime.TabIndex = 42;
            this.btDateTime.Text = "SET DATE/TIME";
            this.btDateTime.UseVisualStyleBackColor = true;
            this.btDateTime.Click += new System.EventHandler(this.btDateTime_Click);
            // 
            // btSave
            // 
            this.btSave.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btSave.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Yellow;
            this.btSave.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btSave.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btSave.Location = new System.Drawing.Point(133, 420);
            this.btSave.Name = "btSave";
            this.btSave.Size = new System.Drawing.Size(105, 50);
            this.btSave.TabIndex = 43;
            this.btSave.Text = "SAVE";
            this.btSave.UseVisualStyleBackColor = true;
            this.btSave.Click += new System.EventHandler(this.btSave_Click_1);
            // 
            // btCancel
            // 
            this.btCancel.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btCancel.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Yellow;
            this.btCancel.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btCancel.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCancel.Location = new System.Drawing.Point(263, 420);
            this.btCancel.Name = "btCancel";
            this.btCancel.Size = new System.Drawing.Size(105, 50);
            this.btCancel.TabIndex = 44;
            this.btCancel.Text = "CANCEL";
            this.btCancel.UseVisualStyleBackColor = true;
            this.btCancel.Click += new System.EventHandler(this.btCancel_Click_1);
            // 
            // lbWarning
            // 
            this.lbWarning.AutoSize = true;
            this.lbWarning.Font = new System.Drawing.Font("Arial Black", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbWarning.ForeColor = System.Drawing.Color.Red;
            this.lbWarning.Location = new System.Drawing.Point(150, 430);
            this.lbWarning.Name = "lbWarning";
            this.lbWarning.Size = new System.Drawing.Size(0, 18);
            this.lbWarning.TabIndex = 45;
            this.lbWarning.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(404, 7);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(384, 58);
            this.pictureBox1.TabIndex = 46;
            this.pictureBox1.TabStop = false;
            // 
            // btShutDown
            // 
            this.btShutDown.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btShutDown.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Yellow;
            this.btShutDown.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btShutDown.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btShutDown.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btShutDown.Location = new System.Drawing.Point(618, 420);
            this.btShutDown.Name = "btShutDown";
            this.btShutDown.Size = new System.Drawing.Size(160, 50);
            this.btShutDown.TabIndex = 47;
            this.btShutDown.Text = "SHUTDOWN";
            this.btShutDown.UseVisualStyleBackColor = true;
            this.btShutDown.Click += new System.EventHandler(this.btShutDown_Click);
            // 
            // tbGrade6
            // 
            this.tbGrade6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbGrade6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbGrade6.Location = new System.Drawing.Point(270, 186);
            this.tbGrade6.MaxLength = 4;
            this.tbGrade6.Name = "tbGrade6";
            this.tbGrade6.Size = new System.Drawing.Size(50, 26);
            this.tbGrade6.TabIndex = 51;
            // 
            // lbGrade6
            // 
            this.lbGrade6.AutoSize = true;
            this.lbGrade6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbGrade6.Location = new System.Drawing.Point(195, 188);
            this.lbGrade6.Name = "lbGrade6";
            this.lbGrade6.Size = new System.Drawing.Size(74, 19);
            this.lbGrade6.TabIndex = 50;
            this.lbGrade6.Text = "Grade 6:";
            // 
            // tbGrade5
            // 
            this.tbGrade5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbGrade5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbGrade5.Location = new System.Drawing.Point(88, 183);
            this.tbGrade5.MaxLength = 4;
            this.tbGrade5.Name = "tbGrade5";
            this.tbGrade5.Size = new System.Drawing.Size(50, 26);
            this.tbGrade5.TabIndex = 49;
            // 
            // lbGrade5
            // 
            this.lbGrade5.AutoSize = true;
            this.lbGrade5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbGrade5.Location = new System.Drawing.Point(16, 190);
            this.lbGrade5.Name = "lbGrade5";
            this.lbGrade5.Size = new System.Drawing.Size(74, 19);
            this.lbGrade5.TabIndex = 48;
            this.lbGrade5.Text = "Grade 5:";
            // 
            // btPageDown
            // 
            this.btPageDown.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btPageDown.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Yellow;
            this.btPageDown.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btPageDown.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btPageDown.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btPageDown.Location = new System.Drawing.Point(617, 339);
            this.btPageDown.Name = "btPageDown";
            this.btPageDown.Size = new System.Drawing.Size(160, 50);
            this.btPageDown.TabIndex = 58;
            this.btPageDown.Text = "NEXT 10\r\nTRANSACTIONS";
            this.btPageDown.UseVisualStyleBackColor = true;
            this.btPageDown.Click += new System.EventHandler(this.btPageDown_Click);
            // 
            // btPageUp
            // 
            this.btPageUp.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btPageUp.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Yellow;
            this.btPageUp.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btPageUp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btPageUp.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btPageUp.Location = new System.Drawing.Point(415, 339);
            this.btPageUp.Name = "btPageUp";
            this.btPageUp.Size = new System.Drawing.Size(160, 50);
            this.btPageUp.TabIndex = 57;
            this.btPageUp.Text = "PREVIOUS 10\r\nTRANSACTIONS";
            this.btPageUp.UseVisualStyleBackColor = true;
            this.btPageUp.Click += new System.EventHandler(this.btPageUp_Click);
            // 
            // btLoggingSFC
            // 
            this.btLoggingSFC.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btLoggingSFC.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Yellow;
            this.btLoggingSFC.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btLoggingSFC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btLoggingSFC.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btLoggingSFC.Location = new System.Drawing.Point(618, 279);
            this.btLoggingSFC.Name = "btLoggingSFC";
            this.btLoggingSFC.Size = new System.Drawing.Size(160, 50);
            this.btLoggingSFC.TabIndex = 56;
            this.btLoggingSFC.Text = "LOGGING\r\nSFC - OFF";
            this.btLoggingSFC.UseVisualStyleBackColor = true;
            this.btLoggingSFC.Click += new System.EventHandler(this.btLoggingSFC_Click);
            // 
            // btLoggingPIC
            // 
            this.btLoggingPIC.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btLoggingPIC.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Yellow;
            this.btLoggingPIC.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btLoggingPIC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btLoggingPIC.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btLoggingPIC.Location = new System.Drawing.Point(415, 278);
            this.btLoggingPIC.Name = "btLoggingPIC";
            this.btLoggingPIC.Size = new System.Drawing.Size(160, 50);
            this.btLoggingPIC.TabIndex = 55;
            this.btLoggingPIC.Text = "LOGGING\r\nPIC - OFF";
            this.btLoggingPIC.UseVisualStyleBackColor = true;
            this.btLoggingPIC.Click += new System.EventHandler(this.btLoggingPIC_Click);
            // 
            // btDownloadReports
            // 
            this.btDownloadReports.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btDownloadReports.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Yellow;
            this.btDownloadReports.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btDownloadReports.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btDownloadReports.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btDownloadReports.Location = new System.Drawing.Point(545, 339);
            this.btDownloadReports.Name = "btDownloadReports";
            this.btDownloadReports.Size = new System.Drawing.Size(105, 50);
            this.btDownloadReports.TabIndex = 61;
            this.btDownloadReports.Text = "COPY\r\nREPORTS";
            this.btDownloadReports.UseVisualStyleBackColor = true;
            this.btDownloadReports.Click += new System.EventHandler(this.btDownloadReports_Click);
            // 
            // btDownloadData
            // 
            this.btDownloadData.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btDownloadData.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Yellow;
            this.btDownloadData.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btDownloadData.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btDownloadData.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btDownloadData.Location = new System.Drawing.Point(673, 339);
            this.btDownloadData.Name = "btDownloadData";
            this.btDownloadData.Size = new System.Drawing.Size(105, 50);
            this.btDownloadData.TabIndex = 60;
            this.btDownloadData.Text = "COPY\r\nDATA";
            this.btDownloadData.UseVisualStyleBackColor = true;
            this.btDownloadData.Click += new System.EventHandler(this.btDownloadData_Click);
            // 
            // btDownloadLogs
            // 
            this.btDownloadLogs.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btDownloadLogs.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Yellow;
            this.btDownloadLogs.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btDownloadLogs.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btDownloadLogs.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btDownloadLogs.Location = new System.Drawing.Point(414, 339);
            this.btDownloadLogs.Name = "btDownloadLogs";
            this.btDownloadLogs.Size = new System.Drawing.Size(105, 50);
            this.btDownloadLogs.TabIndex = 59;
            this.btDownloadLogs.Text = "COPY\r\nLOGS";
            this.btDownloadLogs.UseVisualStyleBackColor = true;
            this.btDownloadLogs.Click += new System.EventHandler(this.btDownloadLogs_Click);
            // 
            // btClear
            // 
            this.btClear.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btClear.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Yellow;
            this.btClear.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btClear.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btClear.Location = new System.Drawing.Point(414, 339);
            this.btClear.Name = "btClear";
            this.btClear.Size = new System.Drawing.Size(363, 50);
            this.btClear.TabIndex = 62;
            this.btClear.Text = "CLEAR";
            this.btClear.UseVisualStyleBackColor = true;
            this.btClear.Click += new System.EventHandler(this.btClear_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 480);
            this.Controls.Add(this.btClear);
            this.Controls.Add(this.btDownloadReports);
            this.Controls.Add(this.btDownloadData);
            this.Controls.Add(this.btDownloadLogs);
            this.Controls.Add(this.btPageDown);
            this.Controls.Add(this.btPageUp);
            this.Controls.Add(this.btLoggingSFC);
            this.Controls.Add(this.btLoggingPIC);
            this.Controls.Add(this.tbGrade6);
            this.Controls.Add(this.lbGrade6);
            this.Controls.Add(this.tbGrade5);
            this.Controls.Add(this.lbGrade5);
            this.Controls.Add(this.btShutDown);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lbWarning);
            this.Controls.Add(this.btCancel);
            this.Controls.Add(this.btSave);
            this.Controls.Add(this.btDateTime);
            this.Controls.Add(this.tbFooter);
            this.Controls.Add(this.lbFooter);
            this.Controls.Add(this.tbHeader);
            this.Controls.Add(this.lbHeader);
            this.Controls.Add(this.tbGrade4);
            this.Controls.Add(this.lbGrade4);
            this.Controls.Add(this.tbGrade3);
            this.Controls.Add(this.lbGrade3);
            this.Controls.Add(this.tbGrade2);
            this.Controls.Add(this.lbGrade2);
            this.Controls.Add(this.tbGrade1);
            this.Controls.Add(this.lbGrade1);
            this.Controls.Add(this.tbMaxBills);
            this.Controls.Add(this.lbMaxBills);
            this.Controls.Add(this.tbMaxCash);
            this.Controls.Add(this.lbMaxCash);
            this.Controls.Add(this.tbPumpNum);
            this.Controls.Add(this.lbPumpNum);
            this.Controls.Add(this.tbPicNum);
            this.Controls.Add(this.lbPicNum);
            this.Controls.Add(this.btRestart);
            this.Controls.Add(this.btUpdate);
            this.Controls.Add(this.btStatus);
            this.Controls.Add(this.btConfigure);
            this.Controls.Add(this.btGenerate);
            this.Controls.Add(this.btPrint);
            this.Controls.Add(this.btCash);
            this.Controls.Add(this.btEOD);
            this.Controls.Add(this.btCompleted);
            this.Controls.Add(this.btPending);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Button button1;
        public System.Windows.Forms.Button button2;
        public System.Windows.Forms.Button button3;
        public System.Windows.Forms.Button button4;
        public System.Windows.Forms.Button button5;
        public System.Windows.Forms.Button button6;
        public System.Windows.Forms.Button button7;
        public System.Windows.Forms.Button button8;
        public System.Windows.Forms.Button button9;
        public System.Windows.Forms.Button button10;
        public System.Windows.Forms.Button btPending;
        public System.Windows.Forms.Button btCompleted;
        public System.Windows.Forms.Button btEOD;
        public System.Windows.Forms.Button btCash;
        public System.Windows.Forms.Button btPrint;
        public System.Windows.Forms.Button btGenerate;
        public System.Windows.Forms.Button btConfigure;
        public System.Windows.Forms.Button btStatus;
        public System.Windows.Forms.Button btUpdate;
        public System.Windows.Forms.Button btRestart;
        public System.Windows.Forms.Label lbPicNum;
        public System.Windows.Forms.TextBox tbPicNum;
        public System.Windows.Forms.TextBox tbPumpNum;
        public System.Windows.Forms.Label lbPumpNum;
        public System.Windows.Forms.TextBox tbMaxBills;
        public System.Windows.Forms.Label lbMaxBills;
        public System.Windows.Forms.TextBox tbMaxCash;
        public System.Windows.Forms.Label lbMaxCash;
        public System.Windows.Forms.TextBox tbGrade4;
        public System.Windows.Forms.Label lbGrade4;
        public System.Windows.Forms.TextBox tbGrade3;
        public System.Windows.Forms.Label lbGrade3;
        public System.Windows.Forms.TextBox tbGrade2;
        public System.Windows.Forms.Label lbGrade2;
        public System.Windows.Forms.TextBox tbGrade1;
        public System.Windows.Forms.Label lbGrade1;
        public System.Windows.Forms.TextBox tbHeader;
        public System.Windows.Forms.Label lbHeader;
        public System.Windows.Forms.TextBox tbFooter;
        public System.Windows.Forms.Label lbFooter;
        public System.Windows.Forms.Button btDateTime;
        public System.Windows.Forms.Button btSave;
        public System.Windows.Forms.Button btCancel;
        public System.Windows.Forms.Label lbWarning;
        private System.Windows.Forms.PictureBox pictureBox1;
        public System.Windows.Forms.Button btShutDown;
        public System.Windows.Forms.TextBox tbGrade6;
        public System.Windows.Forms.Label lbGrade6;
        public System.Windows.Forms.TextBox tbGrade5;
        public System.Windows.Forms.Label lbGrade5;
        public System.Windows.Forms.Button btPageDown;
        public System.Windows.Forms.Button btPageUp;
        public System.Windows.Forms.Button btLoggingSFC;
        public System.Windows.Forms.Button btLoggingPIC;
        public System.Windows.Forms.Button btDownloadReports;
        public System.Windows.Forms.Button btDownloadData;
        public System.Windows.Forms.Button btDownloadLogs;
        public System.Windows.Forms.Button btClear;
    }
}

